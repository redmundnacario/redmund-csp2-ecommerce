<?php

session_start();
// load functions php
require_once '../myfunctions.php';

displayTotalCart1();

?>