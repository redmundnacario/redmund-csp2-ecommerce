<?php

// if (!isset($_SESSION["current_user"])) {
// 	if () {
// 		unset($_SESSION["total_1"]);
// 		unset($_SESSION["item_count"]);
// 		unset($_SESSION["final_price"]);
// 		unset($_SESSION["cart"]);
// 	}
// }

?>