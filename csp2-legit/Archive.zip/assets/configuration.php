<?php
define("PROJECT_HOME","http://localhost/honeyken/");

define("PORT", "587");
define("MAIL_USERNAME", "redmund.nacario@gmail.com");
define("MAIL_PASSWORD", "redimundo");
define("MAIL_HOST", "smtp.gmail.com");
define("MAILER", "smtp");

define("SENDER_NAME", "Honeyken");
define("SERDER_EMAIL", "redmund.nacario@gmail.com");
?>