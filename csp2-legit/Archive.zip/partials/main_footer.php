<footer class="main-footer container-fluid ">
	<div class="container-fluid main-footer-social">
		<p>Follow Us</p>
		<a href="#" class="fa fa-facebook-square footer-icon"></a>
		<a href="#" class="fa fa-instagram footer-icon"></a>
		<a href="#" class="fa fa-twitter-square footer-icon"></a>
		<p>Copyright &copy; 2018 by Honeyken Coffee</p>
	</div>	
</footer>