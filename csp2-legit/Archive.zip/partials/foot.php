	<!-- imports jquery -->
	<script type="text/javascript" src="assets/lib/jquery-3.2.1.min.js"></script>

	<!-- imports bootstrap.js -->
	<script type="text/javascript" src="assets/css/bootstrap-3.3.7-dist/js/bootstrap.min.js"></script>
	<script type="text/javascript" src="assets/js/jquery.bootstrap-growl.js"></script>
	
	<!-- imports custom javascript -->
	<script type="text/javascript" src="assets/js/script.js"></script>