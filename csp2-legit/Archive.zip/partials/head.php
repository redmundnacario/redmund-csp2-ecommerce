<!DOCTYPE html>
<html lang=en>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0">
	<meta http-equiv="X-UA-Compatible" content="IE=Edge">

	<title>Honeyken Coffee</title>

	<!-- Font Awesome -->
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	
	<!-- import bootstrap css -->
	<link rel="stylesheet" type="text/css" href="assets/css/bootstrap-3.3.7-dist/css/bootstrap.min.css">

	<!-- import css -->
	<link rel="stylesheet" type="text/css" href="assets/css/style.css">

	<!-- Google fonts -->
	<link href="https://fonts.googleapis.com/css?family=Nunito|Merriweather|Open+Sans|Pacifico|Cabin|Cuprum|Dosis|Kaushan+Script" rel="stylesheet">
	<!-- Dowload fonts later.. avoid using google fonts -->

