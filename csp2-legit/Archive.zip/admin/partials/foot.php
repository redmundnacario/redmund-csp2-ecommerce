	<!-- import jquery -->
	<script type="text/javascript" src="../assets/lib/jquery-3.2.1.min.js"></script>

	<!-- import bootstrap.js -->
	<script type="text/javascript" src="../assets/css/bootstrap-3.3.7-dist/js/bootstrap.min.js"></script>

	<!-- import custom js -->
	<script type="text/javascript" src="../assets/js/script.js"></script>